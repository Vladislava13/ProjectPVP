﻿export class CardCity {
    id: number;
    name: string;
}