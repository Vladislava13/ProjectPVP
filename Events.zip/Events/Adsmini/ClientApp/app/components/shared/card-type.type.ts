﻿export class CardType {
    id: number;
    name: string;
}